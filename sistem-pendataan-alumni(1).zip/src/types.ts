export type EmploymentType = 'PNS' | 'Swasta' | 'Wirausaha';

export interface Alumnus {
  id?: string;
  name: string;
  email: string;
  phone: string;
  linkedin: string;
  instagram: string;
  facebook: string;
  tiktok: string;
  workplace: string;
  workplaceAddress: string;
  position: string;
  employmentType: EmploymentType | '';
  workplaceSocial: string;
  // New fields
  nim: string;
  tahun_masuk: string;
  tanggal_lulus: string;
  fakultas: string;
  program_studi: string;
  createdBy: string;
  createdAt: any;
  updatedAt: any;
}
