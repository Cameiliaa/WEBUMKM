import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  User
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  query,
  orderBy,
  serverTimestamp,
  getDocs,
  writeBatch
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

// 🔥 INIT
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// 🔥 AUTH PROVIDER
const googleProvider = new GoogleAuthProvider();

// 🔐 AUTH FUNCTIONS
export const loginWithGoogle = () => signInWithPopup(auth, googleProvider);

export const loginWithEmail = (email: string, pass: string) =>
  signInWithEmailAndPassword(auth, email, pass);

export const logout = () => signOut(auth);

// 👤 AUTH LISTENER
export const listenAuth = (callback: (user: User | null) => void) => {
  return onAuthStateChanged(auth, callback);
};

// 📦 COLLECTION REF
const alumniRef = collection(db, "alumni");

// 📥 GET ALL DATA (LIST)
export const getAllAlumni = async () => {
  try {
    const q = query(alumniRef, orderBy("createdAt", "desc"));
    const snapshot = await getDocs(q);

    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, "alumni");
  }
};

// ➕ ADD DATA
export const addAlumni = async (data: any) => {
  try {
    return await addDoc(alumniRef, {
      ...data,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, "alumni");
  }
};

// ✏️ UPDATE DATA
export const updateAlumni = async (id: string, data: any) => {
  try {
    const docRef = doc(db, "alumni", id);
    return await updateDoc(docRef, {
      ...data,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, "alumni");
  }
};

// ❌ DELETE DATA
export const deleteAlumni = async (id: string) => {
  try {
    const docRef = doc(db, "alumni", id);
    return await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, "alumni");
  }
};

// 🚀 BULK IMPORT DATA (Batch writing with chunking)
export const bulkImportAlumni = async (
  dataList: any[],
  userId: string,
  onProgress: (done: number, total: number) => void
) => {
  const CHUNK_SIZE = 500; // Firestore limit per batch
  const total = dataList.length;
  let done = 0;

  for (let i = 0; i < total; i += CHUNK_SIZE) {
    const chunk = dataList.slice(i, i + CHUNK_SIZE);
    const batch = writeBatch(db);

    chunk.forEach((data) => {
      const newDocRef = doc(alumniRef);
      batch.set(newDocRef, {
        ...data,
        name: data.name || 'Unknown',
        nim: data.nim || '',
        tahun_masuk: data.tahun_masuk || '',
        fakultas: data.fakultas || '',
        program_studi: data.program_studi || '',
        createdBy: userId,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    });

    try {
      await batch.commit();
      done += chunk.length;
      onProgress(done, total);
    } catch (error) {
      console.error(`Error committing batch starting at ${i}:`, error);
      handleFirestoreError(error, OperationType.WRITE, `alumni-bulk-chunk-${i}`);
    }
  }
  return true;
};

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}

// 🔥 ERROR HANDLER
export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path
  };

  console.error("🔥 Firestore Error:", errInfo);
  throw new Error(JSON.stringify(errInfo));
}
