import React from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { collection, onSnapshot, query, orderBy, addDoc, updateDoc, deleteDoc, doc, serverTimestamp, writeBatch } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType, logout, bulkImportAlumni } from './lib/firebase';
import { Alumnus } from './types';
import Login from './components/Login';
import AlumniForm from './components/AlumniForm';
import AlumniList from './components/AlumniList';
import CSVImport from './components/CSVImport';
import { Plus, LogOut, Upload, Users, Briefcase, TrendingUp, Download, Database } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Papa from 'papaparse';
import { cn } from './lib/utils';

export default function App() {
  const [user, setUser] = React.useState<User | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [alumni, setAlumni] = React.useState<Alumnus[]>([]);
  const [showForm, setShowForm] = React.useState(false);
  const [showImport, setShowImport] = React.useState(false);
  const [editingAlumnus, setEditingAlumnus] = React.useState<Alumnus| null>(null);

  React.useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  React.useEffect(() => {
    if (!user) {
      setAlumni([]);
      return;
    }

    const q = query(collection(db, 'alumni'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const data = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as Alumnus[];
        setAlumni(data);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'alumni');
      }
    );

    return () => unsubscribe();
  }, [user]);

  const handleAddAlumni = async (data: Partial<Alumnus>) => {
    if (!user) return;
    try {
      await addDoc(collection(db, 'alumni'), {
        ...data,
        createdBy: user.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setShowForm(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'alumni');
    }
  };

  const handleUpdateAlumni = async (data: Partial<Alumnus>) => {
    if (!user || !editingAlumnus?.id) return;
    try {
      await updateDoc(doc(db, 'alumni', editingAlumnus.id), {
        ...data,
        updatedAt: serverTimestamp(),
      });
      setEditingAlumnus(null);
      setShowForm(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `alumni/${editingAlumnus.id}`);
    }
  };

  const handleDeleteAlumni = async (id: string) => {
    if (!user || !window.confirm('Hapus data alumni ini?')) return;
    try {
      await deleteDoc(doc(db, 'alumni', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `alumni/${id}`);
    }
  };

  const handleBulkImport = async (dataList: Partial<Alumnus>[], onProgress?: (done: number, total: number) => void) => {
    if (!user) return;
    try {
      await bulkImportAlumni(dataList, user.uid, (done, total) => {
        if (onProgress) onProgress(done, total);
        console.log(`Import progress: ${done}/${total}`);
      });
      setShowImport(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'alumni-bulk');
    }
  };

  const exportToCSV = () => {
    const csvData = alumni.map(a => ({
      'Nama': a.name,
      'Email': a.email,
      'No HP': a.phone,
      'Linkedin': a.linkedin,
      'Instagram': a.instagram,
      'Facebook': a.facebook,
      'Tiktok': a.tiktok,
      'Tempat Bekerja': a.workplace,
      'Alamat Bekerja': a.workplaceAddress,
      'Posisi': a.position,
      'Status': a.employmentType,
      'Sosial Media Kantor': a.workplaceSocial,
      'NIM': a.nim,
      'Tahun Masuk': a.tahun_masuk,
      'Tanggal Lulus': a.tanggal_lulus,
      'Fakultas': a.fakultas,
      'Program Studi': a.program_studi
    }));
    
    const csv = Papa.unparse(csvData);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `data_alumni_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-indigo-600/20 border-t-indigo-600 rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  const pnsCount = alumni.filter(a => a.employmentType === 'PNS').length;
  const swastaCount = alumni.filter(a => a.employmentType === 'Swasta').length;
  const wirausahaCount = alumni.filter(a => a.employmentType === 'Wirausaha').length;

  return (
    <div className="min-h-screen bg-slate-50 pb-20 font-sans text-slate-900">
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-sm shadow-indigo-200">
                <Users size={18} />
              </div>
              <h1 className="text-xl font-bold tracking-tight text-slate-800">
                Alumni<span className="text-indigo-600">Nexus</span>
                <span className="ml-2 text-slate-400 font-normal text-xs uppercase tracking-widest">Database</span>
              </h1>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-indigo-50 border border-indigo-100 rounded-full">
                <Database size={12} className="text-indigo-600" />
                <span className="text-[10px] font-bold text-indigo-700 uppercase tracking-wider">Cloud Analytics Active</span>
              </div>
              <div className="h-4 w-px bg-slate-200 mx-2"></div>
              <div className="flex items-center gap-3">
                <div className="text-right hidden sm:block">
                  <p className="text-xs font-semibold text-slate-800">{user.displayName || 'Admin'}</p>
                  <p className="text-[10px] text-slate-500">{user.email}</p>
                </div>
                <button 
                  onClick={logout}
                  className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                  title="Keluar"
                >
                  <LogOut size={20} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-1">
            <h1 className="text-3xl font-bold text-slate-800 tracking-tight">Data Alumni Cloud</h1>
            <p className="text-slate-500 text-sm">Penyimpanan terpusat untuk monitoring karir alumni secara real-time.</p>
          </div>
          
          <div className="flex flex-wrap items-center gap-3">
            <button 
              onClick={exportToCSV}
              className="flex items-center gap-2 px-4 py-2 bg-white text-slate-700 rounded-lg text-sm font-semibold border border-slate-200 shadow-sm hover:bg-slate-50 transition-all"
            >
              <Download size={16} />
              Ekspor CSV
            </button>
            <button 
              onClick={() => setShowImport(true)}
              className="flex items-center gap-2 px-4 py-2 bg-white text-slate-700 rounded-lg text-sm font-semibold border border-slate-200 shadow-sm hover:bg-slate-50 transition-all"
            >
              <Upload size={16} />
              Import CSV
            </button>
            <button 
              onClick={() => { setEditingAlumnus(null); setShowForm(true); }}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-semibold shadow-sm shadow-indigo-200 hover:bg-indigo-700 transition-all"
            >
              <Plus size={16} />
              Tambah Alumni
            </button>
          </div>
        </header>

        <section className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { label: 'Total Alumni', value: alumni.length, icon: Users, color: 'bg-indigo-50 text-indigo-600' },
            { label: 'Status PNS', value: pnsCount, icon: Briefcase, color: 'bg-purple-50 text-purple-600' },
            { label: 'Status Swasta', value: swastaCount, icon: TrendingUp, color: 'bg-blue-50 text-blue-600' },
            { label: 'Wirausaha', value: wirausahaCount, icon: Users, color: 'bg-green-50 text-green-600' },
          ].map((stat, i) => (
            <div key={i} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col space-y-2">
              <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">{stat.label}</p>
              <div className="flex items-center justify-between">
                <p className={cn("text-2xl font-bold", stat.color.split(' ')[1])}>{stat.value.toLocaleString()}</p>
                <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", stat.color.split(' ')[0])}>
                  <stat.icon size={16} />
                </div>
              </div>
            </div>
          ))}
        </section>

        <AlumniList 
          alumni={alumni} 
          onEdit={(a) => { setEditingAlumnus(a); setShowForm(true); }}
          onDelete={handleDeleteAlumni}
        />
      </main>

      <AnimatePresence>
        {showForm && (
          <AlumniForm 
            title={editingAlumnus ? 'Edit Alumni' : 'Tambah Alumni'}
            initialData={editingAlumnus || {}}
            onClose={() => { setShowForm(false); setEditingAlumnus(null); }}
            onSubmit={editingAlumnus ? handleUpdateAlumni : handleAddAlumni}
          />
        )}
        {showImport && (
          <CSVImport 
            onClose={() => setShowImport(false)}
            onImport={handleBulkImport}
          />
        )}
      </AnimatePresence>

      <footer className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 border-t border-slate-200 flex justify-between items-center text-slate-400">
        <p className="text-[10px] uppercase font-bold tracking-widest italic">
          Database Terenkripsi • Khusus Pengajar
        </p>
        <p className="text-[10px] font-bold uppercase tracking-widest">
          AlumniNexus Cloud © 2026
        </p>
      </footer>
    </div>
  );
}
