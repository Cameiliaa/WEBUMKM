import React from 'react';
import Papa from 'papaparse';
import { Upload, X, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { Alumnus } from '../types';

interface CSVImportProps {
  onImport: (data: Partial<Alumnus>[], onProgress?: (done: number, total: number) => void) => Promise<void>;
  onClose: () => void;
}

export default function CSVImport({ onImport, onClose }: CSVImportProps) {
  const [file, setFile] = React.useState<File | null>(null);
  const [preview, setPreview] = React.useState<any[]>([]);
  const [error, setError] = React.useState<string | null>(null);
  const [importing, setImporting] = React.useState(false);
  const [progress, setProgress] = React.useState({ done: 0, total: 0 });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.type !== 'text/csv' && !selectedFile.name.endsWith('.csv')) {
        setError('Hanya file CSV yang diperbolehkan');
        return;
      }
      setFile(selectedFile);
      Papa.parse(selectedFile, {
        header: true,
        skipEmptyLines: true,
        preview: 5,
        complete: (results) => {
          setPreview(results.data);
          setError(null);
        },
        error: (err) => {
          setError('Gagal membaca file CSV: ' + err.message);
        }
      });
    }
  };

  const handleImport = async () => {
    if (!file) return;
    setImporting(true);
    setError(null);

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        try {
          const alumniData: Partial<Alumnus>[] = results.data.map((row: any) => {
            // Helper to find value regardless of casing or with/without underscore
            const getVal = (keys: string[]) => {
              for (const k of keys) {
                if (row[k] !== undefined) return row[k];
                // Try case-insensitive
                const foundKey = Object.keys(row).find(rk => rk.toLowerCase() === k.toLowerCase());
                if (foundKey) return row[foundKey];
              }
              return '';
            };

            return {
              name: getVal(['Nama', 'name', 'nama']),
              email: getVal(['Email', 'email', 'e-mail']),
              phone: getVal(['No HP', 'phone', 'telepon', 'hp', 'phone_number']),
              linkedin: getVal(['Linkedin', 'linkedin', 'li']),
              instagram: getVal(['Instagram', 'instagram', 'ig']),
              facebook: getVal(['Facebook', 'facebook', 'fb']),
              tiktok: getVal(['Tiktok', 'tiktok']),
              workplace: getVal(['Tempat Bekerja', 'workplace', 'perusahaan', 'kantor']),
              position: getVal(['Posisi', 'position', 'jabatan']),
              nim: getVal(['NIM', 'nim', 'stambuk', 'id']),
              tahun_masuk: getVal(['Tahun Masuk', 'tahun_masuk', 'angkatan']),
              fakultas: getVal(['Fakultas', 'fakultas', 'faculty']),
              program_studi: getVal(['Program Studi', 'program_studi', 'prodi', 'jurusan']),
            };
          });

          // Filter out items that don't have at least a name
          const validAlumni = alumniData.filter(a => a.name);
          
          if (validAlumni.length === 0) {
            setError('Tidak ada data valid yang ditemukan (minimal harus ada kolom Nama)');
            setImporting(false);
            return;
          }

          setProgress({ done: 0, total: validAlumni.length });
          
          await onImport(validAlumni, (done, total) => setProgress({ done, total }));
          
        } catch (err: any) {
          setError('Terjadi kesalahan saat memproses data: ' + err.message);
        } finally {
          setImporting(false);
        }
      }
    });
  };

  // We expose progress to parent or handle it here.
  // Let's handle progress via state sync if parent provides callback.
  // But App.tsx is already using handleBulkImport.
  // I will modify App.tsx to use the new bulkImportAlumni.

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-xl w-full max-w-xl shadow-2xl overflow-hidden border border-slate-200"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-lg flex items-center justify-center">
              <Upload size={20} />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-800">Impor Data Massal</h2>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Mendukung ribuan data sekaligus</p>
            </div>
          </div>
          {!importing && (
            <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-600 transition-colors">
              <X size={18} />
            </button>
          )}
        </div>

        <div className="p-8 space-y-6">
          {!importing ? (
            <>
              <label className="border-2 border-dashed border-slate-200 rounded-xl p-10 flex flex-col items-center justify-center gap-4 cursor-pointer hover:border-indigo-600 hover:bg-slate-50 transition-all group">
                <input type="file" accept=".csv" onChange={handleFileChange} className="hidden" />
                <div className="w-12 h-12 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Upload size={24} />
                </div>
                <div className="text-center">
                  <p className="text-slate-900 font-bold block text-sm">Pilih file CSV</p>
                  <p className="text-slate-400 text-xs mt-1">Sistem akan memetakan kolom secara otomatis</p>
                </div>
              </label>

              {error && (
                <div className="p-4 bg-red-50 text-red-600 text-xs font-semibold rounded-lg flex items-start gap-3 border border-red-100">
                  <AlertCircle size={16} className="shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {file && !error && (
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-4 bg-indigo-50/50 rounded-lg border border-indigo-100">
                    <CheckCircle2 size={18} className="text-indigo-600" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-slate-800 truncate">{file.name}</p>
                      <p className="text-[10px] text-slate-400 font-bold">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
                    </div>
                  </div>

                  {preview.length > 0 && (
                    <div className="space-y-2">
                      <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Pratinjau Kolom Terdeteksi</h3>
                      <div className="border border-slate-100 rounded-lg overflow-hidden overflow-x-auto">
                        <table className="min-w-full text-[10px] text-left">
                          <thead className="bg-slate-50 text-slate-500 font-bold uppercase">
                            <tr>
                              {Object.keys(preview[0]).map(key => (
                                <th key={key} className="px-3 py-2 border-b border-slate-100">
                                  {key}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {preview.map((row, i) => (
                              <tr key={i}>
                                {Object.values(row).map((val: any, j) => (
                                  <td key={j} className="px-3 py-2 text-slate-600 whitespace-nowrap">
                                    {val?.toString() || '-'}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </>
          ) : (
            <div className="flex flex-col items-center justify-center p-10 space-y-6">
              <div className="relative">
                <Loader2 size={48} className="text-indigo-600 animate-spin" />
                <div className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-indigo-700">
                  {Math.round((progress.done / progress.total) * 100 || 0)}%
                </div>
              </div>
              <div className="text-center space-y-2 w-full max-w-xs">
                <h3 className="text-sm font-bold text-slate-800">Sedang Mengunggah Data...</h3>
                <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${(progress.done / progress.total) * 100}%` }}
                    className="bg-indigo-600 h-full"
                  />
                </div>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                  {progress.done.toLocaleString()} / {progress.total.toLocaleString()} Data Selesai
                </p>
                <p className="text-xs text-slate-500 italic">
                  Jangan tutup jendela ini hingga proses selesai.
                </p>
              </div>
            </div>
          )}
        </div>

        {!importing && (
          <div className="p-6 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-3">
            <button onClick={onClose} className="px-6 py-2 text-sm font-semibold text-slate-500 hover:text-slate-800 transition-colors">
              Batal
            </button>
            <button 
              onClick={handleImport}
              disabled={!file || !!error}
              className="px-10 py-2.5 bg-indigo-600 text-white rounded-lg text-sm font-semibold hover:bg-indigo-700 shadow-sm shadow-indigo-100 transition-all disabled:opacity-50"
            >
              Proses & Impor
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
}
