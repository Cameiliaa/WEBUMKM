import React from 'react';
import { Alumnus } from '../types';
import { 
  MoreHorizontal, Edit2, Trash2, Mail, Phone, 
  Linkedin, Instagram, Facebook, Share2, 
  Briefcase, MapPin, Search
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface AlumniListProps {
  alumni: Alumnus[];
  onEdit: (alumnus: Alumnus) => void;
  onDelete: (id: string) => void;
}

export default function AlumniList({ alumni, onEdit, onDelete }: AlumniListProps) {
  const [search, setSearch] = React.useState('');
  const [activeMenu, setActiveMenu] = React.useState<string | null>(null);

  const filteredAlumni = alumni.filter(a => 
    a.name.toLowerCase().includes(search.toLowerCase()) ||
    a.workplace.toLowerCase().includes(search.toLowerCase()) ||
    a.email.toLowerCase().includes(search.toLowerCase()) ||
    (a.nim && a.nim.toLowerCase().includes(search.toLowerCase())) ||
    (a.fakultas && a.fakultas.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-8">
      <div className="relative max-w-sm">
        <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none text-slate-400">
          <Search size={16} />
        </div>
        <input 
          type="text" 
          placeholder="Cari alumni, instansi, atau email..." 
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-12 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600 transition-all text-sm placeholder:text-slate-400"
        />
      </div>

      <div className="overflow-x-auto">
        <div className="inline-block min-w-full align-middle">
          <div className="overflow-hidden border border-slate-200 rounded-xl shadow-sm">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">
                  <th scope="col" className="px-6 py-4 text-left">Nama & NIM</th>
                  <th scope="col" className="px-6 py-4 text-left">Email & HP</th>
                  <th scope="col" className="px-6 py-4 text-left">Posisi & Instansi</th>
                  <th scope="col" className="px-6 py-4 text-left">Status Kerja</th>
                  <th scope="col" className="px-6 py-4 text-left">Sosial Media</th>
                  <th scope="col" className="px-6 py-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-100">
                <AnimatePresence mode="popLayout">
                  {filteredAlumni.map((alumnus) => (
                    <motion.tr
                      layout
                      key={alumnus.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="hover:bg-slate-50 transition-colors group"
                    >
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-700 text-xs font-bold shrink-0">
                            {alumnus.name.charAt(0)}
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-800">{alumnus.name}</p>
                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{alumnus.nim || 'NIM: -'}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-sm text-slate-600">{alumnus.email}</p>
                        <p className="text-[10px] text-slate-400 font-medium">{alumnus.phone || '-'}</p>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-sm font-medium text-slate-800 leading-tight">{alumnus.position || '-'}</p>
                        <p className="text-[11px] text-slate-500">{alumnus.workplace || '-'}</p>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={cn(
                          "px-2 py-1 text-[10px] font-bold uppercase tracking-wider rounded border",
                          alumnus.employmentType === 'PNS' ? "bg-purple-50 text-purple-600 border-purple-100" :
                          alumnus.employmentType === 'Swasta' ? "bg-blue-50 text-blue-600 border-blue-100" :
                          alumnus.employmentType === 'Wirausaha' ? "bg-orange-50 text-orange-600 border-orange-100" :
                          "bg-slate-50 text-slate-400 border-slate-100"
                        )}>
                          {alumnus.employmentType || 'N/A'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1.5 grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                          {alumnus.linkedin && (
                            <a href={alumnus.linkedin} target="_blank" rel="noopener noreferrer" className="p-1.5 hover:bg-slate-100 rounded-md transition-colors" title="LinkedIn">
                              <Linkedin size={14} className="text-indigo-600" />
                            </a>
                          )}
                          {alumnus.instagram && (
                            <a href={`https://instagram.com/${alumnus.instagram.replace('@', '')}`} target="_blank" rel="noopener noreferrer" className="p-1.5 hover:bg-slate-100 rounded-md transition-colors" title="Instagram">
                              <Instagram size={14} className="text-pink-600" />
                            </a>
                          )}
                          {alumnus.facebook && (
                            <a href={alumnus.facebook} target="_blank" rel="noopener noreferrer" className="p-1.5 hover:bg-slate-100 rounded-md transition-colors" title="Facebook">
                              <Facebook size={14} className="text-blue-700" />
                            </a>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right relative">
                        <button 
                          onClick={() => setActiveMenu(activeMenu === alumnus.id ? null : alumnus.id!)}
                          className="p-1.5 hover:bg-slate-100 rounded-md text-slate-400 hover:text-slate-600 transition-colors"
                        >
                          <MoreHorizontal size={18} />
                        </button>
                        
                        {activeMenu === alumnus.id && (
                          <>
                            <div className="fixed inset-0 z-10" onClick={() => setActiveMenu(null)} />
                            <div className="absolute right-6 top-12 w-40 bg-white border border-slate-200 rounded-lg shadow-xl z-20 overflow-hidden ring-1 ring-black ring-opacity-5">
                              <button 
                                onClick={() => { onEdit(alumnus); setActiveMenu(null); }}
                                className="w-full flex items-center gap-2.5 px-4 py-2.5 text-xs font-semibold text-slate-600 hover:bg-slate-50 text-left"
                              >
                                <Edit2 size={14} /> Edit Data
                              </button>
                              <button 
                                onClick={() => { onDelete(alumnus.id!); setActiveMenu(null); }}
                                className="w-full flex items-center gap-2.5 px-4 py-2.5 text-xs font-semibold text-red-600 hover:bg-red-50 text-left border-t border-slate-50"
                              >
                                <Trash2 size={14} /> Hapus Data
                              </button>
                            </div>
                          </>
                        )}
                      </td>
                    </motion.tr>
                  ))}
                </AnimatePresence>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      {filteredAlumni.length === 0 && (
        <div className="py-20 text-center space-y-3 bg-slate-50 rounded-xl border border-dashed border-slate-200">
          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto text-slate-300 shadow-sm">
            <Search size={24} />
          </div>
          <p className="text-slate-400 text-sm font-medium">Data alumni tidak ditemukan atau masih kosong.</p>
        </div>
      )}
    </div>
  );
}
