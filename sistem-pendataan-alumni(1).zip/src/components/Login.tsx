import React from 'react';
import { motion } from 'motion/react';
import { LogIn, GraduationCap, Mail, Lock } from 'lucide-react';
import { loginWithGoogle, loginWithEmail } from '../lib/firebase';

export default function Login() {
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [showEmailLogin, setShowEmailLogin] = React.useState(false);

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      await loginWithGoogle();
    } catch (err: any) {
      setError(err.message || 'Gagal login. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    setLoading(true);
    setError(null);
    try {
      await loginWithEmail(email, password);
    } catch (err: any) {
      let msg = 'Gagal login.';
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        msg = 'Email atau kata sandi salah.';
      } else if (err.code === 'auth/invalid-email') {
        msg = 'Format email tidak valid.';
      }
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 font-sans">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full bg-white rounded-2xl p-10 shadow-sm border border-slate-200"
      >
        <div className="flex flex-col items-center text-center space-y-8">
          <div className="w-16 h-16 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-100">
            <GraduationCap size={32} />
          </div>
          
          <div className="space-y-2">
            <h1 className="text-2xl font-bold text-slate-800 tracking-tight">Sistem AlumniNexus</h1>
            <p className="text-slate-500 text-sm">
              Sistem pendataan terpadu untuk monitoring karir dan profil sosial media alumni.
            </p>
          </div>

          {error && (
            <div className="w-full p-4 bg-red-50 text-red-600 text-[11px] font-bold rounded-lg border border-red-100 uppercase tracking-wider">
              {error}
            </div>
          )}

          <div className="w-full space-y-6">
            {!showEmailLogin ? (
              <div className="space-y-4">
                <button
                  onClick={handleGoogleLogin}
                  disabled={loading}
                  className="w-full flex items-center justify-center gap-3 bg-indigo-600 hover:bg-indigo-700 text-white py-3.5 rounded-xl transition-all font-semibold shadow-sm shadow-indigo-100 disabled:opacity-50 disabled:cursor-not-allowed group"
                >
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <LogIn size={20} />
                      <span>Masuk dengan Google</span>
                    </>
                  )}
                </button>
                <div className="flex items-center gap-4 py-2">
                  <div className="h-px bg-slate-100 flex-1"></div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">atau</span>
                  <div className="h-px bg-slate-100 flex-1"></div>
                </div>
                <button
                  onClick={() => setShowEmailLogin(true)}
                  className="w-full text-slate-500 text-xs font-bold hover:text-indigo-600 transition-colors uppercase tracking-widest"
                >
                  Masuk dengan Email Admin
                </button>
              </div>
            ) : (
              <form onSubmit={handleEmailLogin} className="space-y-4 text-left">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                    <input 
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="admin@example.com"
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Kata Sandi</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                    <input 
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600"
                      required
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-slate-900 border border-slate-800 text-white py-3 rounded-xl text-sm font-bold shadow-lg shadow-slate-200 hover:bg-black transition-all mt-2 disabled:opacity-50"
                >
                  {loading ? 'Menghubungkan...' : 'Masuk ke Sistem'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowEmailLogin(false)}
                  className="w-full text-slate-400 text-[10px] font-bold uppercase tracking-widest hover:text-slate-600 transition-colors py-2"
                >
                  Kembali
                </button>
              </form>
            )}
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Akses Dibatasi Khusus Pengajar</p>
          </div>
          
          <div className="pt-6 border-t border-slate-100 w-full">
            <div className="flex items-center gap-2 justify-center text-[10px] font-bold text-green-600 uppercase tracking-wider mb-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              Server Aman & Terenkripsi
            </div>
            <p className="text-[10px] text-slate-400 leading-relaxed italic">
              Kerahasiaan data adalah prioritas utama. Penyalahgunaan data alumni akan diproses sesuai hukum yang berlaku.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
