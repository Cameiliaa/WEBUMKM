import React from 'react';
import { Alumnus, EmploymentType } from '../types';
import { X, Save } from 'lucide-react';
import { motion } from 'motion/react';

interface AlumniFormProps {
  initialData?: Partial<Alumnus>;
  onSubmit: (data: Partial<Alumnus>) => void;
  onClose: () => void;
  title: string;
}

export default function AlumniForm({ initialData, onSubmit, onClose, title }: AlumniFormProps) {
  const getDefaultState = (): Alumnus => ({
    name: '',
    email: '',
    phone: '',
    linkedin: '',
    instagram: '',
    facebook: '',
    tiktok: '',
    workplace: '',
    workplaceAddress: '',
    position: '',
    employmentType: '',
    workplaceSocial: '',
    nim: '',
    tahun_masuk: '',
    tanggal_lulus: '',
    fakultas: '',
    program_studi: '',
    createdBy: '',
    createdAt: null,
    updatedAt: null,
  });

  const [formData, setFormData] = React.useState<Partial<Alumnus>>(() => {
    const defaults = getDefaultState();
    if (initialData) {
      // Merge initialData into defaults to ensure no field is undefined
      const merged = { ...defaults };
      Object.keys(initialData).forEach((key) => {
        const val = (initialData as any)[key];
        if (val !== undefined && val !== null) {
          (merged as any)[key] = val;
        }
      });
      return merged;
    }
    return defaults;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Clean up data and remove immutable fields
    const { id, createdBy, createdAt, updatedAt, ...rest } = formData;
    const cleanedData = Object.entries(rest).reduce((acc, [key, value]) => {
      acc[key] = value === null || value === undefined ? '' : value;
      return acc;
    }, {} as any);
    onSubmit(cleanedData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl border border-slate-200"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div>
            <h2 className="text-lg font-bold text-slate-800">{title}</h2>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">Formulir Data Alumni</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-600 transition-colors">
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-8 space-y-8">
          <div className="grid md:grid-cols-2 gap-8">
            <section className="space-y-4">
              <h3 className="text-[10px] uppercase tracking-widest text-indigo-600 font-bold mb-4">Informasi Dasar</h3>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">Nama Lengkap</label>
                <input required name="name" value={formData.name} onChange={handleChange} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600" />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">Email</label>
                <input required type="email" name="email" value={formData.email} onChange={handleChange} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600" />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">No HP</label>
                <input name="phone" value={formData.phone} onChange={handleChange} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600" />
              </div>
            </section>

            <section className="space-y-4">
              <h3 className="text-[10px] uppercase tracking-widest text-indigo-600 font-bold mb-4">Profil Publik</h3>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">LinkedIn URL</label>
                <input name="linkedin" value={formData.linkedin} onChange={handleChange} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600" />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">Instagram</label>
                <input name="instagram" value={formData.instagram} onChange={handleChange} placeholder="@username" className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">Facebook</label>
                  <input name="facebook" value={formData.facebook} onChange={handleChange} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">Tiktok</label>
                  <input name="tiktok" value={formData.tiktok} onChange={handleChange} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600" />
                </div>
              </div>
            </section>
          </div>

          <section className="space-y-4">
            <h3 className="text-[10px] uppercase tracking-widest text-indigo-600 font-bold mb-4">Informasi Karir & Instansi</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">Nama Perusahaan/Instansi</label>
                <input name="workplace" value={formData.workplace} onChange={handleChange} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600" />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">Kategori Pekerjaan</label>
                <select name="employmentType" value={formData.employmentType} onChange={handleChange} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600">
                  <option value="">Pilih Kategori</option>
                  <option value="PNS">PNS / ASN</option>
                  <option value="Swasta">Sektor Swasta</option>
                  <option value="Wirausaha">Wirausaha / Mandiri</option>
                </select>
              </div>
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Posisi / Jabatan</label>
              <input name="position" value={formData.position} onChange={handleChange} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600" />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Alamat Lengkap Kantor</label>
              <input name="workplaceAddress" value={formData.workplaceAddress} onChange={handleChange} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600" />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Website / Sosial Media Instansi</label>
              <input name="workplaceSocial" value={formData.workplaceSocial} onChange={handleChange} placeholder="https://..." className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600" />
            </div>
          </section>

          <section className="space-y-4">
            <h3 className="text-[10px] uppercase tracking-widest text-indigo-600 font-bold mb-4">Informasi Akademik</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">NIM</label>
                <input name="nim" value={formData.nim} onChange={handleChange} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600" />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">Tahun Masuk</label>
                <input name="tahun_masuk" value={formData.tahun_masuk} onChange={handleChange} placeholder="Contoh: 2020" className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600" />
              </div>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">Tanggal Lulus</label>
                <input name="tanggal_lulus" value={formData.tanggal_lulus} onChange={handleChange} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600" />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">Program Studi</label>
                <input name="program_studi" value={formData.program_studi} onChange={handleChange} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600" />
              </div>
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Fakultas</label>
              <input name="fakultas" value={formData.fakultas} onChange={handleChange} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600" />
            </div>
          </section>
        </form>

        <div className="p-6 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-3">
          <button onClick={onClose} className="px-6 py-2 text-sm font-semibold text-slate-500 hover:text-slate-800 transition-colors">
            Batal
          </button>
          <button onClick={handleSubmit} className="px-8 py-2.5 bg-indigo-600 text-white rounded-lg text-sm font-semibold flex items-center gap-2 hover:bg-indigo-700 shadow-sm shadow-indigo-100 transition-all">
            <Save size={16} />
            Simpan Data
          </button>
        </div>
      </motion.div>
    </div>
  );
}
